package paises

data class Country(
    val nombre_pais: String,
    val capital: String,
    val nombre_pais_int: String,
    val sigla: String
)
